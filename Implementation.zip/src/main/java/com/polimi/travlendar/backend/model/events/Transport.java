package com.polimi.travlendar.backend.model.events;

public enum Transport {
	CAR, BIKE, FOOT, TRAIN, PUBLIC;
}
